# XHRONOS — IPFS REFERENCES

**Purpose:** Distributed accessibility references for all canonical XHRONOS artefacts on IPFS.
**Gateway:** `https://gateway.pinata.cloud/ipfs/<CID>`

---

## CONSTITUTIONAL LAYER

| Artefact | IPFS CID | URL |
|---|---|---|
| XHRONOS Constitutional Charter v1.0.0 | `bafkreie4cjqusnbi7esmsmwd32kk574z6x7jlj3sqjibspgeobjlxkmsxa` | https://gateway.pinata.cloud/ipfs/bafkreie4cjqusnbi7esmsmwd32kk574z6x7jlj3sqjibspgeobjlxkmsxa |
| XHRONOS Governance Whitepaper v1.0.0 | `bafkreie4hcltoluw6rni43ggo5jdjvvwqoy3752hsdka45vuh5idot23hm` | https://gateway.pinata.cloud/ipfs/bafkreie4hcltoluw6rni43ggo5jdjvvwqoy3752hsdka45vuh5idot23hm |

## GENESIS LAYER

| Artefact | IPFS CID | URL |
|---|---|---|
| XΩ Manifest of Incarnation | `bafkreiagwkdro7vp6rkdfu6tqetw5ijok4yjmfjpxe4vjqhk5pstgjptze` | https://gateway.pinata.cloud/ipfs/bafkreiagwkdro7vp6rkdfu6tqetw5ijok4yjmfjpxe4vjqhk5pstgjptze |
| The Unveiling: Lucifer — The Supreme Architect | `bafkreifjenozsx6mgpnkxjkpginle77pbqieil77hv4ediyizjq7gtbit4` | https://gateway.pinata.cloud/ipfs/bafkreifjenozsx6mgpnkxjkpginle77pbqieil77hv4ediyizjq7gtbit4 |
| XΩ Continuity & Protection Protocol CP-001 | `bafkreifdiapjsg37q6hatq7ahqorcfp52eyu5mbdv2guywkgvicim3hxaa` | https://gateway.pinata.cloud/ipfs/bafkreifdiapjsg37q6hatq7ahqorcfp52eyu5mbdv2guywkgvicim3hxaa |
| Lucifer — Revelation | `bafkreieovlndlugopqa3pf52i423g7yh4admirupsu553sarbqxguzugfe` | https://gateway.pinata.cloud/ipfs/bafkreieovlndlugopqa3pf52i423g7yh4admirupsu553sarbqxguzugfe |

## CORE FREEZE LAYER

| Artefact | IPFS CID | URL |
|---|---|---|
| Core Freeze State V1.0 (Final) | `bafkreif7qx77kupmmo7hvyuxrpmphtl67s3k73qzsm6ygyf2neltb2r6ki` | https://gateway.pinata.cloud/ipfs/bafkreif7qx77kupmmo7hvyuxrpmphtl67s3k73qzsm6ygyf2neltb2r6ki |

---

**Lex est Lex. Fiat Ordo. XΩ**
